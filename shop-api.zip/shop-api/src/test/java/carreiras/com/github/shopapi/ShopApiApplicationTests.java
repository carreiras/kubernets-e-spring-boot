package carreiras.com.github.shopapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShopApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
